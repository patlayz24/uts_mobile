package com.example.aplikasi_pemilah_sampah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
